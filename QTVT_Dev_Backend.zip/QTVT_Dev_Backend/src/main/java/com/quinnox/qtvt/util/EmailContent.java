package com.quinnox.qtvt.util;

public class EmailContent {
	public static String emailContent() {
		String email=new String("<html>\r\n" + 
				"<head>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"Submitted Details\r\n" + 
				"<table align=\"center\" width=\"100%\" cellpadding=\"5\" style=\"font-size:75%;font-family:Arial;border-collapse:collapse;border:1px solid black;\">\r\n" + 
				"\r\n" + 
				"<tbody><tr>\r\n" + 
				"\r\n" + 
				"<th bgcolor=\"#54549A\" colspan=\"2\" style=\"text-align:left;\"><font color=\"white\" style=\"font-family:Arial,serif,EmojiFont;\">Submitted Details</font> </th>\r\n" + 
				"\r\n" + 
				"</tr>\r\n" + 
				"\r\n" + 
				"<tr>\r\n" + 
				"\r\n" + 
				"<td align=\"left\" style=\"font-weight:bold;text-align:left;background-color:#DAEDF9;border:1px solid black;\">\r\n" + 
				"\r\n" + 
				"Employee Id :</td>\r\n" + 
				"\r\n" + 
				"<td style=\"border:1px solid black;\">id</td>\r\n" + 
				"\r\n" + 
				"</tr>\r\n" + 
				"\r\n" + 
				"<tr>\r\n" + 
				"\r\n" + 
				"<td align=\"left\" style=\"font-weight:bold;text-align:left;background-color:#DAEDF9;border:1px solid black;\">\r\n" + 
				"\r\n" + 
				"Employee Name:</td>\r\n" + 
				"\r\n" + 
				"<td style=\"border:1px solid black;\">name</td>\r\n" + 
				"\r\n" + 
				"</tr>\r\n" + 
				"\r\n" + 
				"<tr>\r\n" + 
				"\r\n" + 
				"<td align=\"left\" style=\"font-weight:bold;text-align:left;background-color:#DAEDF9;border:1px solid black;\">\r\n" + 
				"\r\n" + 
				"From Date :</td>\r\n" + 
				"\r\n" + 
				"<td style=\"border:1px solid black;\">fromDate</td>\r\n" + 
				"\r\n" + 
				"</tr>\r\n" + 
				"\r\n" + 
				"<tr>\r\n" + 
				"\r\n" + 
				"<td align=\"left\" style=\"font-weight:bold;text-align:left;background-color:#DAEDF9;border:1px solid black;\">\r\n" + 
				"\r\n" + 
				"To Date :</td>\r\n" + 
				"\r\n" + 
				"<td style=\"border:1px solid black;\">toDate</td>\r\n" + 
				"\r\n" + 
				"</tr>\r\n" + 
				"\r\n" + 
				"<tr>\r\n" + 
				"\r\n" + 
				"<td align=\"left\" style=\"font-weight:bold;text-align:left;background-color:#DAEDF9;border:1px solid black;\">\r\n" + 
				"\r\n" + 
				"Skills :</td>\r\n" + 
				"\r\n" + 
				"<td style=\"border:1px solid black;\">techSkills</td>\r\n" + 
				"\r\n" + 
				"</tr>\r\n" + 
				"\r\n" + 
				"<tr>\r\n" + 
				"\r\n" + 
				"<td align=\"left\" style=\"font-weight:bold;text-align:left;background-color:#DAEDF9;border:1px solid black;\">\r\n" + 
				"\r\n" + 
				"RMG Comments :</td>\r\n" + 
				"\r\n" + 
				"<td style=\"border:1px solid black;\">RMGComments</td>\r\n" + 
				"\r\n" + 
				"</tr>\r\n" + 
				"\r\n" + 
				"<tr>\r\n" + 
				"\r\n" + 
				"<td align=\"left\" style=\"font-weight:bold;text-align:left;background-color:#DAEDF9;border:1px solid black;\">\r\n" + 
				"\r\n" + 
				"Assigned Manager :</td>\r\n" + 
				"\r\n" + 
				"<td style=\"border:1px solid black;\">assignedManager</td>\r\n" + 
				"\r\n" + 
				"</tr>\r\n" + 
				"\r\n" + 
				"</tbody></table>\r\n" + 
				"</body>\r\n" + 
				"</html>");
		return email;
	}
	
	public static String emailContentSubmission() {
		String email=new String("\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"Submitted Details\r\n" + 
				"<table align=\"center\" width=\"90%\" cellpadding=\"5\" style=\"font-size:75%;font-family:Arial;border-collapse:collapse;\">\r\n" + 
				"\r\n" + 
				"<tbody><tr>\r\n" + 
				"\r\n" + 
				"<th bgcolor=\"#54549A\" colspan=\"2\" style=\"text-align:left;\"><font color=\"white\" style=\"font-family:Arial,serif,EmojiFont;\">Submitted Details</font> </th>\r\n" + 
				"\r\n" + 
				"</tr>\r\n" + 
				"\r\n" + 
				"<tr>\r\n" + 
				"\r\n" + 
				"<td align=\"left\" style=\"font-weight:bold;text-align:left;background-color:#DAEDF9;border:1px solid black;\">\r\n" + 
				"\r\n" + 
				"Employee Id :</td>\r\n" + 
				"\r\n" + 
				"<td style=\"border:1px solid black;\">id</td>\r\n" + 
				"\r\n" + 
				"</tr>\r\n" + 
				"\r\n" + 
				"<tr>\r\n" + 
				"\r\n" + 
				"<td align=\"left\" style=\"font-weight:bold;text-align:left;background-color:#DAEDF9;border:1px solid black;\">\r\n" + 
				"\r\n" + 
				"Employee Name:</td>\r\n" + 
				"\r\n" + 
				"<td style=\"border:1px solid black;\">name</td>\r\n" + 
				"\r\n" + 
				"</tr>\r\n" + 
				"\r\n" + 
				"<tr>\r\n" + 
				"\r\n" + 
				"<td align=\"left\" style=\"font-weight:bold;text-align:left;background-color:#DAEDF9;border:1px solid black;\">\r\n" + 
				"\r\n" + 
				"From Date :</td>\r\n" + 
				"\r\n" + 
				"<td style=\"border:1px solid black;\">fromDate</td>\r\n" + 
				"\r\n" + 
				"</tr>\r\n" + 
				"\r\n" + 
				"<tr>\r\n" + 
				"\r\n" + 
				"<td align=\"left\" style=\"font-weight:bold;text-align:left;background-color:#DAEDF9;border:1px solid black;\">\r\n" + 
				"\r\n" + 
				"To Date :</td>\r\n" + 
				"\r\n" + 
				"<td style=\"border:1px solid black;\">toDate</td>\r\n" + 
				"\r\n" + 
				"</tr>\r\n" + 
				"\r\n" + 
				"<tr>\r\n" + 
				"\r\n" + 
				"<td align=\"left\" style=\"font-weight:bold;text-align:left;background-color:#DAEDF9;border:1px solid black;\">\r\n" + 
				"\r\n" + 
				"Skills :</td>\r\n" + 
				"\r\n" + 
				"<td style=\"border:1px solid black;\">techSkills</td>\r\n" + 
				"\r\n" + 
				"</tr>\r\n" + 
				"\r\n" + 
				"<tr>\r\n" + 
				"\r\n" + 
				"<td align=\"left\" style=\"font-weight:bold;text-align:left;background-color:#DAEDF9;border:1px solid black;\">\r\n" + 
				"\r\n" + 
				"Hours/Total Hours  :</td>\r\n" + 
				"\r\n" + 
				"<td style=\"border:1px solid black;\">submittedHours</td>\r\n" + 
				"\r\n" + 
				"</tr>\r\n" + 
				"\r\n" + 
				"\r\n" + 
				"\r\n" + 
				"</tbody></table>\r\n" + 
				"</body>\r\n" + 
				"</html>");
		return email;
	}

}
