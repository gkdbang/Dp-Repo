package com.quinnox.qtvt.BO;

public class PieChartBO {
	private int allocated;
	private int submitted;
	private int lapsed;
	public int getAllocated() {
		return allocated;
	}
	public void setAllocated(int allocated) {
		this.allocated = allocated;
	}
	public int getSubmitted() {
		return submitted;
	}
	public void setSubmitted(int submitted) {
		this.submitted = submitted;
	}
	public int getLapsed() {
		return lapsed;
	}
	public void setLapsed(int lapsed) {
		this.lapsed = lapsed;
	}

}
