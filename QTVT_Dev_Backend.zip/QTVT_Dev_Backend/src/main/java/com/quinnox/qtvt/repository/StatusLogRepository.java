package com.quinnox.qtvt.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.quinnox.qtvt.model.StatusLog;

public interface StatusLogRepository extends JpaRepository<StatusLog, Long>{

}
